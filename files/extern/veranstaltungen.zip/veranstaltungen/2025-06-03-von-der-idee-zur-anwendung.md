---
layout: post
reihe: SEP
date: 2025-06-03 14:55:05 +0100
title: "Von der Idee zur Anwendung"
sprecher: "Carsten Bruckhoff"
code: "SEP20250603"
status: "past"
categories: sep event
ort: "Seminarraum 25.12.01.51"
zeit: "16:30"
short: " Es sind viele Schritte notwendig, um aus einer Vision eine funktionsfähige Software zu implementieren. Der Vortrag „Von der Idee zur Anwendung – Softwareentwicklung in der Praxis“ stellt an einem realitätsnahen Beispiel aus der Logistik die einzelnen ..."
---

## Zusammenfassung


Es sind viele Schritte notwendig, um aus einer Vision eine funktionsfähige Software zu implementieren.
Der Vortrag „Von der Idee zur Anwendung – Softwareentwicklung in der Praxis“ stellt an einem realitätsnahen Beispiel aus der Logistik die einzelnen Schritte der Softwareentwicklung vor und illustriert die verschiedenen Rollen in diesem Prozess.
Somit gibt der Vortrag einen tieferen Einblick in den Alltag eines Informatikers, der im Bereich Entwicklung von betrieblichen Informationssystemen arbeitet.


