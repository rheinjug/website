---
layout: post
reihe: SEP
date: 2021-01-21 14:55:05 +0100
title: "Workshop: Domain Storytelling am Praxisbeispiel"
sprecher: "Jens Bendisposto"
code: "SEP20210121"
status: "past"
categories: sep event
ort: "Seminarraum 25.12.02.33"
zeit: "16:30"
short: ""
---
