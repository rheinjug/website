---
layout: post
reihe: SEP
date: 2024-11-12 14:55:05 +0100
title: "Workshop: Testgetriebene Entwicklung"
sprecher: "Thomas Traude und Kristian Bergmann "
code: "SEP20241112"
status: "past"
categories: sep event
ort: "Seminarraum 25.12.02.33"
zeit: "16:30"
short: ""
---
