---
layout: post
reihe: SEP
date: 2024-11-26 14:55:05 +0100
title: "Workshop: Refactory von Legacy Code"
sprecher: "Roland Weisleder"
code: "SEP20241126"
status: "past"
categories: sep event
ort: "Seminarraum 25.12.02.33"
zeit: "16:30"
short: ""
---
